const { execSync } = require("child_process");

function run(cmd) {
  try {
    return execSync(cmd, { stdio: "pipe" }).toString().trim();
  } catch {
    return "";
  }
}

// 🔍 Get diff
function getDiff() {
  return run("git diff");
}

// 🔍 Get staged + unstaged files
function getChangedFiles() {
  const output = run("git status --porcelain");
  if (!output) return [];

  return output.split("\n").map(line => line.slice(3));
}

// 🧠 Analyze diff like a human reviewer
function analyzeDiff(diff) {
  const added = (diff.match(/^\+[^+]/gm) || []).length;
  const removed = (diff.match(/^\-[^-]/gm) || []).length;

  const hasFunction = /function\s|\=\>\s|\bconst\s+\w+\s*=\s*\(/.test(diff);
  const hasFixWords = /null|undefined|error|bug|fix/i.test(diff);
  const hasConsole = /console\.log/.test(diff);

  let type = "chore";

  if (hasFixWords) type = "fix";
  else if (added > removed && hasFunction) type = "feat";
  else if (removed > added) type = "cleanup";
  else if (added || removed) type = "refactor";

  return { type, added, removed, hasConsole };
}

// 🧠 Generate elite commit message
function generateMessage(analysis, files) {
  const scope = inferScope(files);

  const templates = {
    feat: [
      "add %s functionality",
      "implement %s logic",
      "introduce %s feature"
    ],
    fix: [
      "fix issue in %s",
      "resolve bug in %s",
      "correct %s handling"
    ],
    refactor: [
      "refactor %s for clarity",
      "simplify %s logic",
      "improve %s structure"
    ],
    cleanup: [
      "remove unused %s",
      "clean up %s",
      "delete redundant %s"
    ],
    chore: [
      "update %s",
      "adjust %s",
      "minor changes to %s"
    ]
  };

  const pick = arr => arr[Math.floor(Math.random() * arr.length)];
  const template = pick(templates[analysis.type] || templates.chore);

  return `${analysis.type}: ${template.replace("%s", scope)}`;
}

// 🧠 Infer scope from files
function inferScope(files) {
  if (!files.length) return "codebase";

  const file = files[0].toLowerCase();

  if (file.includes("swap")) return "swap logic";
  if (file.includes("auth")) return "authentication";
  if (file.includes("ui") || file.includes("component")) return "UI";
  if (file.includes("contract")) return "smart contract";
  if (file.includes("api")) return "API";

  return "core logic";
}

// 🚀 Commit logic
let lastCommit = 0;
const MIN_INTERVAL = 1 * 60 * 1000;

function commit() {
  const now = Date.now();

  if (now - lastCommit < MIN_INTERVAL) {
    console.log("⏱ Too soon, skipping...");
    return;
  }

  const diff = getDiff();
  const files = getChangedFiles();

  if (!diff || files.length === 0) {
    console.log("😴 No meaningful changes");
    return;
  }

  const analysis = analyzeDiff(diff);
  const message = generateMessage(analysis, files);

  console.log("🧠 Commit message:", message);

  run("git add .");
  run(`git commit -m "${message}"`);
  run("git push");

  lastCommit = now;

  console.log("🚀 Changes pushed\n");
}


// XO is not alright 
// 🎲 Smarter timing (burst + idle simulation)
function getInterval() {
  const base = Math.random();

  if (base < 0.6) return rand(1, 2);   // active burst
  if (base < 0.9) return rand(2, 5);  // normal
  return rand(3, 7);                  // idle drift
}

function rand(min, max) {
  return (Math.random() * (max - min) + min) * 60 * 1000;
}

async function loop() {
  console.log("🧠 Elite committer active...\n");

  while (true) {
    commit();

    const wait = getInterval();
    console.log(`⏳ Next check in ~${Math.round(wait / 60000)} mins\n`);

    await new Promise(res => setTimeout(res, wait));
  }
}

loop();